<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SignalController extends Controller
{
    public function signal_page()
    {
        return view('traffic_signal');
    }

    public function start_signal(Request $request)
    {

        $status = true;
        $sequenceA = '';
        $sequenceB = '';
        $sequenceC = '';
        $sequenceD = '';
        $GInterval = '';
        $YInterval = '';
        if($request->sequenceA == '' || $request->sequenceA  == null || $request->sequenceA > 4 || $request->sequenceA < 1 || !is_numeric($request->sequenceA))
        {
            $sequenceA = 'Sequence A Is Must Be a Number 1 to 4 And Required';
            $status = false;
        }
        else
        {
            $sequences[] = $request->sequenceA;
        }

        if($request->sequenceB == '' || $request->sequenceB  == null || $request->sequenceB > 4 || $request->sequenceB < 1 || !is_numeric($request->sequenceB))
        {
            $sequenceB = 'Sequence B Is Must Be a Number 1 to 4 And Required';
            $status = false;
        }
        else
        {
            if(in_array($request->sequenceB,$sequences))
            {
                $sequenceB = 'Sequence B is a Duplicate';
                $status = false;
            }
            else
            {
                $sequences[] = $request->sequenceB;
            }
        }
        if($request->sequenceC == '' || $request->sequenceC  == null || $request->sequenceC > 4 || $request->sequenceC < 1 || !is_numeric($request->sequenceC))
        {
            $sequenceC = 'Sequence C Is Must Be a Number 1 to 4 And Required';
            $status = false;
        }
        else
        {
            if(in_array($request->sequenceC,$sequences))
            {
                $sequenceC = 'Sequence C is a Duplicate';
                $status = false;
            }
            else
            {
                $sequences[] = $request->sequenceC;
            }
        }
        if($request->sequenceD == '' || $request->sequenceD  == null || $request->sequenceD > 4 || $request->sequenceD < 1 || !is_numeric($request->sequenceD))
        {
            $sequenceD = 'Sequence D Is Must Be a Number 1 to 4 And Required';
            $status = false;
        }
        else
        {
            if(in_array($request->sequenceD,$sequences))
            {
                $sequenceD = 'Sequence D is a Duplicate';
                $status = false;
            }
            else
            {
                $sequences[] = $request->sequenceD;
            }
        }

        if ($request->GInterval == '' || $request->GInterval  == null || !is_numeric($request->GInterval)) {
            $GInterval = 'Green Interval Must Be a Number & Required';
            $status = false;
        }
        if ($request->YInterval == '' || $request->YInterval  == null || !is_numeric($request->YInterval)) {
            $YInterval = 'Yellow Interval Must Be a Number & Required';
            $status = false;
        }

        $sequences = [
            ['sort_id' => $request->sequenceA,'id' => 'circleA','duration' => $request->YInterval],
            ['sort_id' => $request->sequenceB,'id' => 'circleB','duration' => $request->GInterval],
            ['sort_id' => $request->sequenceC,'id' => 'circleC','duration' => $request->YInterval],
            ['sort_id' => $request->sequenceD,'id' => 'circleD','duration' => $request->YInterval],
        ];
        usort($sequences,function($a,$b){
            return $a['sort_id'] - $b['sort_id'];
        });

        return response(['status' => $status, 'sequenceA' => $sequenceA, 'sequenceB'=> $sequenceB, 'sequenceC'=> $sequenceC, 'sequenceD' => $sequenceD, 'YInterval' => $YInterval, 'GInterval' => $GInterval, 'sequences' => $sequences]);
    }
}

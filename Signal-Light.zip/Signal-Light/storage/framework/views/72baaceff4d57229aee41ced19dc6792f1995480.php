<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <title>Traffic Signal</title>
    <style>
        .circle {
            display: inline-block;
            width: 20px;
            height: 20px;
            margin-top: 10px;
            margin-right: 10px;
            border-radius: 50%;
        }

        .text-danger {
            color: red;
        }

        .color-yellow {
            background-color: yellow;
        }

        .color-green {
            background-color: green;
        }

        .interval-input-div {
            display: inline-block;
            margin-right: 20px;
        }

        .blink-animation {
            animation: blink 1s infinite;
        }

        @keyframes  blink {
            0% {
                opacity: 1;
            }

            50% {
                opacity: 0;
            }

            100% {
                opacity: 1;
            }
        }
    </style>
    <script>
        function valid_numbers(e) {
            var key = e.which || e.KeyCode;
            if (key >= 48 && key <= 57)
                // to check whether pressed key is number or not 
                return true;
            else return false;
        }
      var timeoutIds = []; // Array to store timeout IDs for each sequence

        function startBlinking(elementId, duration) {
            var element = document.getElementById(elementId);
            element.classList.add("blink-animation");
            var timeoutId = setTimeout(function() {
                element.classList.remove("blink-animation");
            }, duration * 1000);
            timeoutIds.push(timeoutId); // Store the timeout ID
        }

        function StartSequenceLoop(sequences) {
            var index = 0;

            // Recursive function to loop through sequences
            function nextSequence() {
                var sequence = sequences[index];
                startBlinking(sequence.id, sequence.duration);
                index = (index + 1) % sequences.length;
                timeoutIds.push(setTimeout(nextSequence, sequence.duration *
                    1000));
            }
            nextSequence();
        }


        function stopSignal() {
            timeoutIds.forEach(function(timeoutId) {
                clearTimeout(timeoutId);
            });
            timeoutIds = [];
            var element = document.querySelectorAll(".blink-animation");
            element.forEach(function(element) {
                element.classList.remove("blink-animation");
            });
        }

        $(document).ready(function() {
            $("#startButton").click(function() {
                $("#startButton").prop('disabled', true);
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    url: "<?php echo e(route('signal.start')); ?>",
                    type: "POST",
                    data: {
                        sequenceA: $("#sequenceAInput").val(),
                        sequenceB: $("#sequenceBInput").val(),
                        sequenceC: $("#sequenceCInput").val(),
                        sequenceD: $("#sequenceDInput").val(),
                        GInterval: $("#green_interval").val(),
                        YInterval: $("#yellow_interval").val()
                    },
                    success: function(response) {
                        if (response.status == false) {
                            $("#sequenceAInputError").html(response.sequenceA);
                            $("#sequenceBInputError").html(response.sequenceB);
                            $("#sequenceCInputError").html(response.sequenceC);
                            $("#sequenceDInputError").html(response.sequenceD);
                            $("#sequenceYintervalInputError").html(response.YInterval);
                            $("#sequenceGintervalInputError").html(response.GInterval);
                            $("#startButton").prop('disabled', false);
                        } else {
                            $("#startButton").prop('disabled', true);
                            StartSequenceLoop(response.sequences);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('Error');
                    }
                });
            });
            $("#stopButton").click(function() {
                $(".text-danger").html('');
                $("#startButton").prop('disabled', false);
                stopSignal();
            });
        });
    </script>
</head>

<body>
    <h1>Traffic Signal</h1>
    <div>
        <span class="circle color-yellow" id="circleA"></span>
        <label for="sequenceAInput">Sequence For Signal A:</label>
        <input type="tel" onkeypress="return valid_numbers(event)" id="sequenceAInput">
        <span class="text-danger" id="sequenceAInputError"></span>
    </div>
    <div>
        <span class="circle color-green" id="circleB"></span>
        <label for="sequenceBInput">Sequence For Signal B:</label>
        <input type="tel" onkeypress="return valid_numbers(event)" id="sequenceBInput">
        <span class="text-danger" id="sequenceBInputError"></span>
    </div>
    <div>
        <span class="circle color-yellow" id="circleC"></span>
        <label for="sequenceCInput">Sequence For Signal C:</label>
        <input type="tel" onkeypress="return valid_numbers(event)" id="sequenceCInput">
        <span class="text-danger" id="sequenceCInputError"></span>
    </div>
    <div>
        <span class="circle color-yellow" id="circleD"></span>
        <label for="sequenceDInput">Sequence For Signal D:</label>
        <input type="tel" onkeypress="return valid_numbers(event)" id="sequenceDInput">
        <span class="text-danger" id="sequenceDInputError"></span>
    </div><br><br>

    <div class="interval-input-div">
        <label for="green_interval">Green Light Interval:</label>
        <input type="tel" onkeypress="return valid_numbers(event)" id="green_interval">
        <span class="text-danger" id="sequenceGintervalInputError"></span>
    </div>
    <div class="interval-input-div">
        <label for="yellow_interval">Yellow Light Interval:</label>
        <input type="tel" onkeypress="return valid_numbers(event)" id="yellow_interval">
        <span class="text-danger" id="sequenceYintervalInputError"></span>
    </div><br><br>
    <button id="startButton">Start Signal</button>
    <button id="stopButton">Stop Signal</button>
</body>

</html>
<?php /**PATH C:\wamp64\www\Signal-Light\resources\views/traffic_signal.blade.php ENDPATH**/ ?>